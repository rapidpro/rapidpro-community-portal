import unittest

from tests.test_image import *
from tests.test_pillow import *
from tests.test_wand import *


if __name__ == '__main__':
    unittest.main()
