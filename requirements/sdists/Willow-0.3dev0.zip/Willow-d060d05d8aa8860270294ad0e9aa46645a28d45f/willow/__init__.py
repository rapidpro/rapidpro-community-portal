from willow.image import Image

__version__ = '0.1'
